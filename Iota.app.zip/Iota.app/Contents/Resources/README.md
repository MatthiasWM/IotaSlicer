# AllPlatformAppFLTK
Use Travis to compile and publish an FLTK app for all platforms (MacOS, MSWindows, Linux, Android)
